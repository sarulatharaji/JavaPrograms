/**
 * Author Name: Sarulatha R Employee Id : 150943 Date: 05.07.2018
 */
package com.dthoperator.exception;

/**
 * @author sarulr
 *
 */
public class RechargeException extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String exceptionMessage;
	
	public RechargeException()
	{
		this.exceptionMessage="Failed to Recharge.";
		
	}
	
	public RechargeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public RechargeException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public RechargeException(String message) 
	{
		super(message);			
	}
	public RechargeException(Throwable cause) 
	{
		super(cause);			
	}
	public String getMessage() {
		return exceptionMessage;
	}

	public void setMessage(String message) {
		this.exceptionMessage = message;
	}
	
}
