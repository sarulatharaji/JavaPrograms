package com.dthoperator.junit;
/**
 * Author Name: Sarulatha R Employee Id : 150943 Date: 05.07.2018
 */

import java.util.ArrayList;




import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.dthoperator.exception.RechargeException;
import com.dthoperator.service.RechargeCollectionHelper;
import com.dthoperator.bean.RechargeDetails;

public class RechargeCollectionHelperTest {
	RechargeCollectionHelper rechargeCollection;
	@BeforeClass
	public void setUp() throws Exception {
		 rechargeCollection=new RechargeCollectionHelper();
	}
	
	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public void tearDown() throws Exception {
		
	}

//	@SuppressWarnings("deprecation")
//	@Test(expected = RechargeException.class)
	@Test
	public void testAddItems() throws RechargeException {
		
		rechargeCollection.addRechargeDetails(new RechargeDetails("Airtel", 1234567890, "Monthly", 123, 3698));
		Assert.assertEquals(2, rechargeCollection.getItems().size());
	}
	
	@Test
	public void test()
	{
		rechargeCollection = null;
		Assert.assertNull(rechargeCollection);
		System.out.println(rechargeCollection);
	}
	

}
	
