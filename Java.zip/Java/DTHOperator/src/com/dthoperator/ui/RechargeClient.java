/**
 * Author Name: Sarulatha R Employee Id : 150943 Date: 05.07.2018
 */
package com.dthoperator.ui;

import java.util.Random;
import java.util.Scanner;

import com.dthoperator.service.RechargeCollectionHelper;
import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.exception.RechargeException;
import com.dthoperator.service.RechargeDataValidator;

/**
 * @author sarulr
 *
 */
public class RechargeClient {

	/**
	 * @param args
	 */		
	static RechargeDataValidator data = new RechargeDataValidator();
	static RechargeCollectionHelper rechargeCollector =null;
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args){
		// TODO Auto-generated method stub
	 rechargeCollector = new RechargeCollectionHelper();
		String choice;
		while(true)
		{
			System.out.println("1. Make a Recharge\n2. Display Recharge Details\n3. Exit.");
			choice=scanner.nextLine();
			switch (choice) {
			case "1":
				//to add recharge details
					addRechargeDetails();
				break;
				
				
			case "2":
				//to display the transaction details 
				RechargeCollectionHelper.displayRechargeDetails();
				break;
			
			case "3":
				//to exit the application
				System.out.println("Exiting...");
				System.exit(0);
			}
		}
	}
	
	public static void addRechargeDetails(){
		// TODO Auto-generated method stub
		String dthOperator;
		int consumerNo;
		String rechargePlan;
		int amount;
		int transactionID;
		System.out.println("Select DTH Operator:\nAirtel\nDishTV\nReliance\nTATASky");
		dthOperator=scanner.nextLine();
		
		try {
			if(RechargeDataValidator.validatedthOperator(dthOperator))
			{
			System.out.println("Enter Registered Consumer No.: ");
			consumerNo=scanner.nextInt();
			scanner.nextLine();
			if(RechargeDataValidator.validateConsumerNo(consumerNo))
			{
				System.out.println("Select Plan(1. Monthly / 2. Quarterly / 3. Half yearly / 4. Annual): ");
				rechargePlan=scanner.nextLine();
				if(RechargeDataValidator.validatePlan(rechargePlan))
				{
					System.out.println("Enter Amount (Rs.): ");
					amount=scanner.nextInt();
					if(RechargeDataValidator.validateAmount(amount))
					{
						Random random=new Random();
						transactionID=random.nextInt();
						System.out.println("Transaction Id is: "+transactionID);
						RechargeDetails cc=new RechargeDetails(dthOperator, consumerNo, rechargePlan, amount, transactionID);
						rechargeCollector.addRechargeDetails(cc);
					}
					else
						throw new RechargeException("Amount should be of 4 numbers");
				}
				else
					throw new RechargeException("Plan should be of given choices");
			}
			else
				throw new RechargeException("ConsumerNo should be of 10 numbers");
			}
		} catch (RechargeException e) {
			// TODO Auto-generated catch block
			System.out.println("Data doesn't match the given details");
		}
	}
}