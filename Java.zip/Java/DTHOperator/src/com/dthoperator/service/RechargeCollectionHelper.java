/**
 * Author Name: Sarulatha R Employee Id : 150943 Date: 05.07.2018
 */
package com.dthoperator.service;

import java.util.ArrayList;
import java.util.Iterator;


import com.dthoperator.exception.RechargeException;
import com.dthoperator.bean.RechargeDetails;

/**
 * @author sarulr
 *
 */
public class RechargeCollectionHelper {

static ArrayList<RechargeDetails> list=null;
	
	public  RechargeCollectionHelper() {
		// TODO Auto-generated constructor stub
		//Sample data added in the list
		list = new ArrayList<>();
		list.add(new RechargeDetails("Airtel", 1089343431, "Monthly", 210, 4567));
		list.add(new RechargeDetails("DishTV", 303321223, "Yearly", 1260, 2345));
		list.add(new RechargeDetails("Reliance", 893434300, "Quaterly", 650, 1234));
	}
	
	//Returns the list
	public ArrayList<RechargeDetails> getItems()
	{
		return list;
	}
	//Sets data in the list
	public static void setRechargeList(ArrayList<RechargeDetails> rechargeDetails) {
		RechargeCollectionHelper.list = rechargeDetails;
	}
	
	//Adding data to the list
	public void addRechargeDetails(RechargeDetails rechargeDetails) throws RechargeException{
		// TODO Auto-generated method stub
		if(list != null)
			list.add(rechargeDetails);
		throw new RechargeException();
			//list.add(rechargeDetails);
	}
	//Displaying Recharge Details 
	public static void displayRechargeDetails() {
		// TODO Auto-generated method stub
		Iterator<RechargeDetails> iterator=list.iterator();
		RechargeDetails tempBook=null;
		while(iterator.hasNext())
		{
			tempBook=iterator.next();
				System.out.println(tempBook);
		}


	}
}
