/**
 * Author Name: Sarulatha R Employee Id : 150943 Date: 05.07.2018
 */
package com.dthoperator.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.dthoperator.exception.RechargeException;

/**
 * @author sarulr
 *
 */
public class RechargeDataValidator {
	
	//validates the operation chosen
	public static boolean validatedthOperator(String dthOperator)
	{
		Pattern pattern = Pattern.compile("[A-Za-z]{3,10}");
		//pattern.matches(dthOperator, pattern)
		Matcher match = pattern.matcher(dthOperator);
		return match.matches();
	}
	//validates the consumer number
	public static boolean validateConsumerNo(int consumerNo)
	{
		Pattern pattern =Pattern.compile("[0-9]{10}");
		String a=Integer.toString(consumerNo);
		Matcher match = pattern.matcher(a);
		return match.matches();
		
	}
	//validate plan chosen
	public static boolean validatePlan(String rechargePlan)
	{
		Pattern  pattern= Pattern.compile("[0-9]{1}");
		Matcher match = pattern.matcher(rechargePlan);
		return match.matches();
	}
	//validate amount entered
	public static boolean validateAmount(int amount)
	{
		Pattern pattern =Pattern.compile("[0-9]{2,3}");
		String a=Integer.toString(amount);
		Matcher match = pattern.matcher(a);
		return match.matches();
		
	}
}
