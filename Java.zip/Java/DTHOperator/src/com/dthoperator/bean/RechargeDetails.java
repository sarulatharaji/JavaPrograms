/**
 * Author Name: Sarulatha R Employee Id : 150943 Date: 05.07.2018
 */
package com.dthoperator.bean;

/**
 * @author sarulr
 *
 */
/**Generates getters and setters for fields used**/

public class RechargeDetails {
	String dthOperator;
	int consumerNo;
	String rechargePlan;
	int amount;
	int transactionID;
	
	public RechargeDetails(String dthOperator, int consumerNo,
			String rechargePlan, int amount, int transactionID) {
		super();
		this.dthOperator = dthOperator;
		this.consumerNo = consumerNo;
		this.rechargePlan = rechargePlan;
		this.amount = amount;
		this.transactionID = transactionID;
	}
	
	/**
	 * returns the dthOperator
	 */
	public String getDthOperator() {
		return dthOperator;
	}
	
	/**
	 *  Value is assigned for dthOperator
	 */
	public void setDthOperator(String dthOperator) {
		this.dthOperator = dthOperator;
	}
	/**
	 * returns the consumerNo
	 */
	public int getConsumerNo() {
		return consumerNo;
	}
	/**
	 *  Value is assigned for consumerNo
	 */
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}
	/**
	 * returns the rechargePlan
	 */
	public String getRechargePlan() {
		return rechargePlan;
	}
	/**
	 *  Value is assigned for  rechargePlan
	 */
	public void setRechargePlan(String rechargePlan) {
		this.rechargePlan = rechargePlan;
	}
	/**
	 * returns the amount
	 */
	public int getAmount() {
		return amount;
	}
	/**
	 *  Value is assigned for amount
	 */
	public void setAmount(int amount) {
		this.amount = amount;
	}
	/**
	 * returns the transactionID
	 */
	public int getTransactionID() {
		return transactionID;
	}
	/**
	 *  Value is assigned for transactionID
	 */
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/**
	 * 
	 * Returns the assigned Recharge details of users
	 */
	@Override
	public String toString() {
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo="
				+ consumerNo + ", rechargePlan=" + rechargePlan + ", amount="
				+ amount + ", transactionID=" + transactionID + "]";
	}
	
}
