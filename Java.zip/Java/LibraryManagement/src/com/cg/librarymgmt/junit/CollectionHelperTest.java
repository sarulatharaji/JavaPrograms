/*******Author Name: Christy JV Emp Id : 101484 Date: 20.5.2017 ******/
//Purpose: To provide test cases of Book Management

package com.cg.librarymgmt.junit;

//import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Test;

import DTHOperator.src.com.dthoperator.bean.RechargeDetails;
import DTHOperator.src.com.dthoperator.exception.ListException;

import com.cg.librarymgmt.bean.BookDetails;
import com.cg.librarymgmt.exception.BookException;
import com.cg.librarymgmt.helper.CollectionHelper;

public class CollectionHelperTest
{
	static CollectionHelper collectionHelper;
	static BookDetails all=null;

	//adding asset details to the array list
	@Before
	public   static  void beforeClass()
	{
		collectionHelper=new CollectionHelper();
		all=new BookDetails("Wings of Fire","Story",12,java.time.LocalDate.now(),888088);		
	}
	
	//clearing the arraylist
	@Test
	public void testToAddNewDetails() throws ListException
	{
		Object r;
//		((Object) r).addRechargeDetails(new RechargeDetails("TATASky", 987456321, "Monthly", 5620, 1478));
//		Assert.assertNotEquals(1, ((Object) r).getItems().size());
	}
	
	@Test
	public void test()
	{
		Object r = null;
		Assert.assertNull(r);
		System.out.println(r);
	}

}
