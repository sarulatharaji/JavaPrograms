package DTHOperator.src.com.dthoperator.service;

import DTHOperator.src.com.dthoperator.bean.RechargeDetails;
import DTHOperator.src.com.dthoperator.exception.ListException;

public interface RechargeCollectionHelper1 {
	public void addRechargeDetails(RechargeDetails rechargeDetails) throws ListException;
	
	public void displayRechargeDetails(int transacctionID);
	
}
