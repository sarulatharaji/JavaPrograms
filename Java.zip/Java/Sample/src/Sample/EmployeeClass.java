package Sample;

public class EmployeeClass {
	int empId;
	String ename;
	public void getDetails(int id,String name)
	{
		empId=id;
		ename=name;
	}
	public void dispDetails()
	{
		System.out.println("Employee ID:"+empId);
		System.out.println("Employee Name:"+ename);
	}
}
