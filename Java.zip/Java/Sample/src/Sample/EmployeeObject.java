package Sample;

public class EmployeeObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeClass e=new EmployeeClass();
		e.getDetails(1413098, "Sarulatha");
		e.dispDetails();
		
		EmployeeClass e1=new EmployeeClass();
		e1.getDetails(1413507, "Malathi");
		e1.dispDetails();
	}

}
