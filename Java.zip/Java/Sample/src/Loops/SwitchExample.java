package Loops;

abstract public class SwitchExample {


	abstract void calculateInterestRate();
	public static void main(String args[])
	{
		
	}
}

class SavingsAccount extends SwitchExample{
public void calculateInterestRate()
{
//  code for calculating interest rate
	System.out.println("fhjdshfiujf");
}

}
