package Loops;

public class SampleInterface implements Sample{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=a+1;
		System.out.println(a+b);
	}

}
