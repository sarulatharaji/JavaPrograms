package Loops;

public interface Sample {
int a=11;
}