package com.capgemini.patient.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import com.capgemini.patient.bean.PatientDetails;


public class PatientHelper{

	private  static ArrayList<PatientDetails> patientList=null;
	static
	{
		patientList=new ArrayList<PatientDetails>();
		PatientDetails patientDetails1=new PatientDetails("sarulatha", 21, "8675672862" , "Severe Fever" , 1102 ,new Date());
		PatientDetails patientDetails2=new PatientDetails("malathi", 21, "9845712548" , "Fever" , 2845 ,new Date());
		patientList.add(patientDetails1);
		patientList.add(patientDetails2);
	}
	
	public PatientHelper(){}
	
	//adding book details to the array list
	
	public void addPatientDetails(PatientDetails patientDetails) {
		// TODO Auto-generated method stub
		patientList.add(patientDetails);
	}
	public static ArrayList<PatientDetails> gePatientList() {
//		System.out.println(patientList);
		return patientList;
	}
	public static void setPatientList(ArrayList<PatientDetails> patientDetails) {
		PatientHelper.patientList = patientDetails;
	}
	
	// Displays available patient details
	public static void searchPatient(int searchId) {
		// TODO Auto-generated method stub
		Iterator<PatientDetails> iterator=patientList.iterator();
		PatientDetails tempBook=null;
		while(iterator.hasNext())
		{
			tempBook=iterator.next();
			if(tempBook.getPatientId()==searchId)
				System.out.println(tempBook);
			else
			{
				System.out.println("There is no patient with this ID");
				break;
			}
		}
	}
}
