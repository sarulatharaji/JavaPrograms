package com.capgemini.patient.service;

import java.util.regex.Pattern;

import com.capgemini.patient.exception.PatientException;
public class PatientValidator {
	public  static  boolean validateName(String name)throws PatientException
	{
		
		String pattern="^[a-zA-Z ]{5,15}";
		if(Pattern.matches(pattern, name))
		{
			return true;
		}
		else
		{
			throw new PatientException("Patient name should be alphabet and Minimum 5 alphabets with a space");
		}
	}
	//validating book type - it should be story or fiction	
	public  static  boolean validateAge(int pAge)throws PatientException
	{
		if(pAge>=1 && pAge<=100)
		{
			return true;
		}
		else
		{
			throw new PatientException("Age should be between 1 and 100");
		}
	}
	
	//validating book quantity - it should be of number and minium 5, maximum 30 
	public  static  boolean validateMobileNumber(String phoneNumber)throws PatientException
	{
		String phoneNoPattern="[0-9]{10}";
		if(Pattern.matches(phoneNoPattern,phoneNumber))
		{
			return true;
		}
		else
		{
			throw new PatientException("Enter a valid mobile number");
		}
	}
	public static boolean validateDesc(String description)throws PatientException
	{
		String pattern="^[a-zA-Z ]{1,40}";
		if(Pattern.matches(pattern, description))		
		{
			return true;
		}
		else
		{
			throw new PatientException("Descriptiom should be alphabet and Maximum 40 characters");
		}
	}
}
