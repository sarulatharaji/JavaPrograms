package com.capgemini.patient.service;

import static org.junit.Assert.*;

import java.util.Date;

import junit.framework.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.patient.bean.PatientDetails;
import com.capgemini.patient.exception.PatientException;

public class PatientHelperTest {
	static PatientHelper patientHelper;
	static PatientDetails all=null;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
	@BeforeClass
	public   static  void beforeClass()
	{
		patientHelper=new PatientHelper();
		all=new PatientDetails("sarulatha", 21, "8675672862" , "Severe Fever" , 1102 ,new Date());
	}
	@AfterClass
	public static void afterClass()
	{		
		patientHelper=null;
		all=null;
	}	
	
	//checking whether asset details are present in array list

	@Test 
	public void testAddPatientDetails() throws PatientException
	{
		patientHelper.addPatientDetails(all);
		Assert.assertNotNull(all.getPatientId());
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
