package com.capgemini.patient.service;

import static org.junit.Assert.*;

import java.util.regex.Pattern;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.patient.exception.PatientException;
import com.capgemini.patient.service.*;
public class PatientValidatorTest {
	@BeforeClass
	public  static  void validateName(String name)
	{
		
		String pattern="^[a-zA-Z ]{5,15}";
		if(Pattern.matches(pattern, name))
			System.out.println("true");
	}
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
