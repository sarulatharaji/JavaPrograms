package com.capgemini.patient.ui;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
//Imported files from user defined packages
import com.capgemini.patient.bean.PatientDetails;
import com.capgemini.patient.exception.PatientException;
import com.capgemini.patient.service.PatientHelper;
import com.capgemini.patient.service.PatientValidator;
public class PatientClient{
	static Scanner scanner=new Scanner(System.in);
	static PatientHelper patientHelper=null;
	public static void main(String[] args) {
	//Scanner scanner=new Scanner(System.in);

	
	String choice;
//	scanner.next();
	patientHelper=new PatientHelper();
	System.out.println("1. Add Patient Information");
	System.out.println("2. Search Patient by Id");
	System.out.println("3. Exit");
	while(true)
	{
//		System.out.println("1. Add Patient Information");
//		System.out.println("2. Search Patient by Id");
//		System.out.println("3. Exit");
		System.out.println("Enter your choice:");
		choice=scanner.nextLine();
	switch(choice)
	{
	case "1":
		enterPatientDetails();
//		collectionhelper.getPatientList();
		break;
	case "2":
		System.out.println("Enter the patient Id to be searched: ");
		int searchId=scanner.nextInt();
		PatientHelper.searchPatient(searchId);
		break;
	case "3":
			System.out.println("Exiting...........");
			System.exit(0);
			break;
	
	}
	}
    }
	private static void enterPatientDetails() 
	{
		String patientName;
		int patientAge;
		int patientID;
		String mobileNo;
		String patientDesc;
		Date consultationDate=new Date();
		System.out.println("Enter the name of the Patient: ");
		patientName=scanner.nextLine();
		try 
		{
			//sending input to validateBookName method for validating book type
			if(PatientValidator.validateName(patientName))
			{
				System.out.println("Enter Patient Age: ");
				patientAge=scanner.nextInt();
				//sending input to validateBookType method for validating book name
				if(PatientValidator.validateAge(patientAge))
				{
					
					System.out.println("Enter Patient phone number: ");
					mobileNo=scanner.next();
					//sending input to validateBookQuanity method for validating book quantity
					if(PatientValidator.validateMobileNumber(mobileNo))
					{
						System.out.println("Enter Description: ");
						patientDesc=scanner.next();
						if(PatientValidator.validateDesc(patientDesc))
						{
						//Generate  Random Reference Id
						Random random=new Random();
						patientID=random.nextInt();
						System.out.println("Patient ID is "+patientID);
						System.out.println("Date is "+LocalDate.now());
						//sending valid input data to the constructor of BookDetails class
						PatientDetails cc=new PatientDetails(patientName, patientAge, mobileNo, patientDesc, patientID, consultationDate);
						patientHelper.addPatientDetails(cc);

						}
					}
				}
			}
		}
		catch(PatientException e)
		{
			System.out.println(e.getMessage());
		}
	}
}