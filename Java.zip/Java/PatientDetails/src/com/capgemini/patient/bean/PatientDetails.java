package com.capgemini.patient.bean;

import java.time.LocalDate;
import java.util.Date;

public class PatientDetails {
	String patientName;
	int patientAge;
	int patientID;
	String mobileNo;
	String patientDesc;
	Date consultationDate;
	public PatientDetails(String patientName, int age, String phoneNumber,
			String description, int patientId, Date consulationDate) {
		super();
		this.patientName = patientName;
		this.patientAge = age;
		this.mobileNo = phoneNumber;
		this.patientDesc = description;
		this.patientID = patientId;
		this.consultationDate = consulationDate;
	}
	public String getPhoneNumber() {
		return mobileNo;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.mobileNo = phoneNumber;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public int getAge() {
		return patientAge;
	}
	public void setAge(int age) {
		this.patientAge = age;
	}
	public String getDescription() {
		return patientDesc;
	}
	public void setDescription(String description) {
		this.patientDesc = description;
	}
	public long getPatientId() {
		return patientID;
	}
	public void setPatientId(int patientId) {
		this.patientID = patientId;
	}
	public Date getCurrentDate() {
		return consultationDate;
	}
	public void setCurrentDate(Date consultationDate) {
		this.consultationDate = consultationDate;
	}
	public String toString() {
		return "Asset [Patient Id: " + patientID + ", Name of the Patient: "
				+ patientName + ", Phone Number: " + mobileNo +", Age: " + patientAge+", Description: "+patientDesc
				+ ", Consultation Date: " + consultationDate + "]";
	}

}
