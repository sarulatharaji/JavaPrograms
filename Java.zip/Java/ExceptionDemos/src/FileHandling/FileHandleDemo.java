package FileHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandleDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		//File file=new File("d:\\sarula.txt");
//		if(file.createNewFile())
//			System.out.println("File created");
//		else
//			System.out.println("File not created");
		FileReader fileRead=new FileReader("d:\\sarula.txt");
		int i;
		while((i=fileRead.read())!=-1)
			System.out.println((char)i);
		fileRead.close();
//		FileWriter fileWrite=new FileWriter();
//		fileWrite.write("Hey guys");
//		fileWrite.close();
//		FileReader fileRead=new FileReader(file);
		
	}

}
