package FileHandling;

import static org.junit.Assert.*;
import org.junit.Test;

public class FileHandleDemoTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Test
	public void testFile()
	{
		Object i;
		Object fileRead;
//		while((i=(fileRead).read())!=-1)
//			System.out.println((char)i);
	}
}
