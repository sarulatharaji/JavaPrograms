package FileHandling;
public class TwoWheeler extends Vehicle {

	public void engineEfficiency()
	{
		System.out.println("Engine Efficiency of two wheeler");
	}
	public static void main(String[] args) 
	{
		TwoWheeler v=new TwoWheeler();
		v.display();
		v.engineEfficiency();
	}

}
