package FileHandling;
public class Dog extends Animal {

	public Dog()
	{
		System.out.println("dog is running");
	}
	public static void main(String[] args) {
		Animal a=new Dog();
		a.color="Brown";
		System.out.println("Color of dog is "+a.color);
		a.sound();		
	}
}
