package FileHandling;
public class EmployeeClass {
	int empId;
	String empName;
	
	public void getDetails(int id, String name)
	{
	empId=id;
	empName=name;
	}
	
	public void displayDetails()
	{
		System.out.println("Employee Id is "+empId);
		System.out.println("Employee Name is "+empName);
	}

	public static void main(String args[])
	{
		EmployeeClass e = new EmployeeClass();
		e.getDetails(101, "Christy");
		e.displayDetails();
	}

}
