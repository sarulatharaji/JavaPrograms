package FileHandling;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Pattern1 {


/**
 * @param args
 */
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	String input = sc.next();
	//String pc = "[0-9]{6}";
	Pattern p=Pattern.compile("[0-9]{6}");
	Matcher ma=p.matcher(input);
	if(ma.matches())
	
//	if(Pattern.matches(pc,input))
	
	//if(input.matches(pc))
			System.out.println("pin code is acceptd");
	else
			System.out.println("Invalid");
	
	
}
}