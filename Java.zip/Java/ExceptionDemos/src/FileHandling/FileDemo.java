package FileHandling;
import java.io.*;  
public class FileDemo {  
    public static void main(String[] args) throws IOException {  
  
            File file = new File("d:\\javaFile1239.txt");  
            if (file.createNewFile()) {  
                System.out.println("New File is created!");  
            } else {  
                System.out.println("File already exists.");  
            }  
            FileWriter fw=new FileWriter("D:\\javaFile12377.txt");
            fw.write("Welcome to VnV." );
            fw.close();
            
            FileReader fr=new FileReader("D:\\javaFile1235.txt");    
            int i;    
            while((i=fr.read())!=-1)    
            System.out.print((char)i);    
            fr.close();    
         
            
    }  
} 