package FileHandling;
public class EmployeeObject {

	public static void main(String[] args) {
		EmployeeClass e = new EmployeeClass();
		e.getDetails(101, "c");
		e.displayDetails();
		
		EmployeeClass e1 =new EmployeeClass();
		e1.getDetails(102, "d");
		e1.displayDetails();
	}

}
