package FileHandling;
import java.util.regex.Pattern;

public class MyPattern {

	public static void main(String[] args) {

		String a="9176120127";
		String pattern="[0-9]{10}";
		
		 boolean patternMatched = 
                 Pattern.matches(pattern, a);           
		 System.out.println(patternMatched);
	        

	}

}
