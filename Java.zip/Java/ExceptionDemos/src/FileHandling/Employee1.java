package FileHandling;
public class Employee1 implements java.io.Serializable {
   public String name;
   public String address;
   public int SSN;

   public void mailCheck() {
      System.out.println("Mailing a check to " + name + " " + address);
   }
}