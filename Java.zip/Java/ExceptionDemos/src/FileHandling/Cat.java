package FileHandling;
public class Cat extends Animal{
	public void sound()
	{
		System.out.println("Cat sound");
	}
	public static void main(String[] args) {
		Animal cat=new Cat();
		cat.color="White";
		System.out.println("Color of cat is"+cat.color);
		cat.sound();
	}

}
