package FileHandling;
public class Animal {
public int legs;
public String color;

public void sound()
{
	System.out.println("Animal sound");
}
	
}
