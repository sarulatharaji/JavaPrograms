package FileHandling;
public abstract class Vehicle {
public void display()
{
	System.out.println("From abstract class Vehicle");
}
public abstract void engineEfficiency();
}
