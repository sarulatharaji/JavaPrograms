package FileHandling;
public class OverloadingDemo {

	int add(int d,int b)
	{
		System.out.println("first method");
		return d+b;
	}
	double add(double a, int b)
	{
		System.out.println("second method");
		return a+b;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverloadingDemo d=new OverloadingDemo();
		int a= d.add(4,5);
		System.out.println("the result is "+a);
		double b=d.add(4.5,3);
		System.out.println("the result is "+b);
	}

}
