package InterfaceDemo;

public interface Apple extends Mango,Orange{
	int a=12,b=34;
	static int val=7;
	final int var=33;
	public int value=90;
}
