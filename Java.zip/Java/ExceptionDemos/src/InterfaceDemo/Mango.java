package InterfaceDemo;

public interface Mango extends Orange{
int a=10;
public int num=11;
public static int val=7;
final int sample=10;
void disp(int a, int b);
}
