package InterfaceDemo;

public class InterfaceDemos implements Apple,Mango,Orange{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Apple apple=new InterfaceDemos();
		apple.disp(25,55);
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(); 
	}

	@Override
	public void disp(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}

}
