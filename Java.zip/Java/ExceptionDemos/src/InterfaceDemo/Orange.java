package InterfaceDemo;

public interface Orange{
default void display()
{
	System.out.println("Hello welcome to orange world");
}
static void disp(int a,int b)
{
	System.out.println(a+b);
}
}
