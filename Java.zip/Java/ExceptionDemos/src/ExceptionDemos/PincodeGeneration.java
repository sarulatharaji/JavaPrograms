package ExceptionDemos;

import java.util.Scanner;

public class PincodeGeneration {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		// TODO Auto-generated method stub
		String pincode=scanner.nextLine();
		String pattern="[0-9]{6}";
		if(pincode.matches(pattern))
			System.out.println("Valid pincode"+pincode);
		else
			System.out.println("Invalid");
	}

}
