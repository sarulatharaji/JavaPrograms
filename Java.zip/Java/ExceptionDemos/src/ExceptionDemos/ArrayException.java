package ExceptionDemos;

public class ArrayException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={2,3,4,5};
		int []arr1=new int[5];
		
		System.out.println("haii before try");
		try
		{
			System.out.println("hello");
		for(int i=0;i<5;i++)
			System.out.println(arr[i]);
		
		System.out.println("haii after try");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
