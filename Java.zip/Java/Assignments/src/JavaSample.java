

interface test
{
	short cnt=0;
	void test();
}
public class JavaSample implements test{
//	public float myMethod(String a, String b)
//	{
//		return 0;
//		
//	}
	public void test()
	{
		int c=0;
		for(int x=6;x>cnt;x--,++c){
			System.out.println(" "+cnt);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x;
		JavaSample d= new JavaSample();
		d.test();
//		A a=new A();
//		a.myMethod(a, b);
//		System.out.println(x);
//		test.i=12;
//		System.out.println(test.i);
	}

}
class A
{
	protected float myMethod(String a, String b)
	{
		return 0;
	}
}