

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class MyIEDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.ie.driver","D:/IEDriverServer.exe");


DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
WebDriver driver = new InternetExplorerDriver(caps);

driver.get("http://demo.opencart.com/");
System.out.println(driver.getTitle());
Thread.sleep(500);
driver.quit();
	}

}
