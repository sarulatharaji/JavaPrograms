package Assignments;

class Sample { 
public static void main(String[] args) { 
	String str = null;                                                                                                                                                                                                                                                               
    System.out.println(str.concat("Hi"));
try { 
int x = 5/0;
} 
catch (NullPointerException nullEx) { 
System.out.print("NullPointerEx."); 
} 
finally { 
System.out.print("finally block"); 
}
 } }