package Assignments;

public class CommandLineInput {

	public static void main(String args[]) {
		// TODO Auto-generated method stub
		System.out.println(args[0]);
		int number=Integer.parseInt(args[0]);
		if(number>0)
			System.out.println("Positive Number");
		else
			System.out.println("Negative Number");
			
	}

}
