package Assignments;

public class PersonalDetailsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonalDetails personalDetails=new PersonalDetails("Sarulatha", "Rajendran" , 'F',"9865874625");
		personalDetails.displayDetails();
	}

}
