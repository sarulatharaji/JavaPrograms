package Assignments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public class Demos {
	
public static void main(String[] args) {

	ArrayList<String> al = new ArrayList<String>();
	  al.add("30");
	  al.add("-30");
	  al.add("ball");
	  al.add("40");
	  al.add("Ball");
	  Collections.sort(al);
	  System.out.println("Contents of al: " + al);
}
}