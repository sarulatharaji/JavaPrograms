package Assignments;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneID {
	public static void main(String[] args) {
		System.out.println("Please enter a zone id");
		Scanner sc=new Scanner(System.in);
		String zone_id=sc.nextLine();
		ZonedDateTime date=ZonedDateTime.now(ZoneId.of(zone_id));
		System.out.println("Date and Time of "+zone_id+" is: "+date);
		sc.close();
	}
}
