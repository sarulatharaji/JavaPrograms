package Assignments;
public class Test {
//	public class TestDemo {
		 public static void main(String[] args) {
		  try {
		     
		     System.out.println(Integer.parseInt("A"));
		     System.out.println(5/0);
		   } catch(ArithmeticException|ArrayIndexOutOfBoundsException e) {
		     System.out.println("Catch 1");
		   } catch(NumberFormatException ne) {
		     System.out.println("Catch 2");
		   }
		finally { System.out.println("fianlly block"); }
		 }
		}