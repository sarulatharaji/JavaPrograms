package Assignments;

import java.time.LocalDate;
import java.util.Date;



class SwitchExample { 
	 
		int number = 30; 
		void add() { 
		number += 5; 
		System.out.println(number); } 
		 
		public static void main(String[] args) { 
		SwitchExample smple = new SwitchExample();
		smple.add(); 
		Date date=new Date();
		System.out.println(date);
		System.out.println(LocalDate.now());
		} } 
