package Assignments;

import java.util.Scanner;
public class StringOperations {
	public static void concatenateString(String string,String add)
	{
		System.out.println(string.concat(add));
	}
	public static void replaceOddCharacters(String string)
	{
		String newWord="";
		String str1=" ";
		char swap='#';
		String temp=" ";
		for(int i=0;i<string.length();i++)
		{
			 if (i % 2 == 0) {

	                temp = "";

	                temp += string.charAt(i);

	                
	                newWord += temp;

	            } else {

	                temp = "";

	                temp += string.charAt(i);

	                temp = temp.replace(string.charAt(i),'#');
	                newWord += temp;

	            }
		}
		System.out.println(newWord);
	}
		
	public static void removeDuplicates(String string)
	{
		char[] change=string.toCharArray();
		int len=change.length;
		for(int i=0;i<len;i++)
		{
			for(int j=i+1;j<len;j++)
			{
				if(change[i]==change[j])
				{
					int temp=j;
					for(int k=j;k<len-1;k++)
					{
						change[k]=change[k+1];
					}
					j--;
					len--;
				}
				
			}
		}
		String noDup=new String(change);
		System.out.println(noDup.substring(0, len));
	}
	public static void oddCharacterUpperCase(String string)
	{
		String caps="";
		String val="";
		for(int i=0;i<string.length();i++)
		{
			
			if(i%2!=0)
			{
				caps=""+string.charAt(i);	
				val=val+caps.toUpperCase();
			}
			else 
			{
			caps=""+string.charAt(i);
			val=val+caps;
			} 
		}
		System.out.println(val);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the string:");
		String string=scanner.nextLine();
		
		System.out.println("1. Add the String to itself.");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove duplicate characters in the String");
		System.out.println("4. Change odd characters to upper case");
		System.out.println("Enter your choice:");
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter string to add:");
			String add=scanner.next();
			concatenateString(string,add);
			break;
		case 2:
			replaceOddCharacters(string);
			break;
		case 3:
			removeDuplicates(string);
			break;
		case 4:
			oddCharacterUpperCase(string);
			break;
		}
	}

}
