package Assignments;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;



public class TimeDuration {


	public void getDuration(String input,DateTimeFormatter df)
	{
		String text=input;
		LocalDate date = LocalDate.parse(text, df);
		System.out.println(date);
        LocalDate now = LocalDate.now();
        
        Period diff = Period.between(date, now);
        System.out.printf("The difference is %d years, %d months, %d days", 
                       diff.getYears(), diff.getMonths(), diff.getDays());
	}
	
	public static void main(String[] args) 
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter date in the given format (DD/MM/YYYY)");
		Scanner scanner = new Scanner(System.in);
		String date=scanner.nextLine();
		TimeDuration timeDuration = new TimeDuration();
		timeDuration.getDuration(date,dtf);
		scanner.close();
	}
}