package Assignments;
import java.io.*;
import java.util.*;
public class PositiveString {
	String alphaOrder(String str)
	{
	char[] charArray=str.toCharArray();
	Arrays.sort(charArray);
	String aString=new String(charArray);
	return aString;
	}
	public static void main(String[] args)throws IOException
	{
	System.out.println("Enter the String: ");
	BufferedReader br=new BufferedReader(new
	InputStreamReader(System.in));
	String inputString=br.readLine();
	PositiveString pos=new PositiveString();
	String alphaString=pos.alphaOrder(inputString);
	if(alphaString.equals(inputString))
	{
		System.out.println("It's a Positive String");
	}
	else
	{
		System.out.println("It's not a Positive String");
	}
	}
	}

	