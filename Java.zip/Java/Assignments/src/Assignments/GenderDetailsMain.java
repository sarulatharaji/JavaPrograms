package Assignments;

import java.util.Scanner;

public class GenderDetailsMain {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the gender:");
		char gender=scanner.next().charAt(0);
		GenderDetails genderDetails=new GenderDetails("Sarulatha", "Rajendran",gender, "9856478956");
		genderDetails.displayDetails();
	 }

}
