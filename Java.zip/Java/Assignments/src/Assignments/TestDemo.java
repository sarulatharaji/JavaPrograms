package Assignments;

import java.util.*;

public class TestDemo 
{
	 public static void main(String args[]) {
		 TreeMap tree=new TreeMap();
		  tree.put("one",1);
		  tree.put("two",2);
		  tree.put("three",3);
		  tree.put("four",4);
			  System.out.println(tree);   
	 }
}