package Assignments;

public class StringCompare {
	
		 public static void main(String[] args) {

		 String a=new String("Hello");
		  String b="Hello";
//		  System.out.println(a == b);
//		  System.out.println(a.equals(b));
		  System.out.println(a.compareTo(b)); 
		}
		}
