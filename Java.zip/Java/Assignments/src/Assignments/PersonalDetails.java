package Assignments;

public class PersonalDetails {
	String firstName;
	String lastName;
	char gender;
	String phoneNumber;
	public PersonalDetails(String firstName,String lastName,char gender,String phoneNumber)
	{
		this.firstName=firstName;
		this.lastName=	lastName;
		this.gender=gender;
		this.phoneNumber=phoneNumber;
	}
	public void displayDetails()
	{
		System.out.println("First Name: "+this.firstName);
		System.out.println("Last Name: "+this.lastName);
		System.out.println("Gender: "+this.gender);
		System.out.println("Phone Number: "+this.phoneNumber);
	}
}
