package Assignments;
enum Gender
{
	M,F,InputNotValid
}
public class GenderDetails {
	String firstName;
	String lastName;
	Gender gender;
	String phoneNumber;
	public GenderDetails(String firstName, String lastName,char gender,String phoneNumber) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		if(gender=='M')
				this.gender=Gender.M;
		else if(gender=='F')
			this.gender=Gender.F;
		else
			this.gender=Gender.InputNotValid;
	}
	
	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public void displayDetails()
	{
		System.out.println("First Name: "+this.firstName);
		System.out.println("Last Name: "+this.lastName);
		System.out.println("Gender: "+getGender());
		System.out.println("Phone Number: "+this.phoneNumber);
	}
}
