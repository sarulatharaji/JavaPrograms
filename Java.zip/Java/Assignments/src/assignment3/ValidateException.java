package assignment3;

public class ValidateException extends Exception {
	String exception;

	public ValidateException(String exception) {
		
		this.exception = exception;
		System.err.println(exception);
	}
}
