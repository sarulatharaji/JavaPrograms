package assignment3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
public class Person {
	private String firstName;
	private String lastName;
	private String gender;
	private long mobileNo;
	static enum gend{
		M,F
	};
	gend ge;
	
	public Person(String firstName, String lastName, String gender, long mobileNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNo = mobileNo;
	}
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		if(ge.M.toString()==gender || ge.F.toString()==gender)
		{
			
		this.gender = gender;
		}
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFullName(){
		
		try
		{
		if(firstName.isEmpty() && lastName.isEmpty()) 
		{
			throw new ValidateException("First Name and Last Name cannot be empty");
		}
		
		}
		catch(ValidateException v){
			v.printStackTrace();
		}
		return (firstName+" "+lastName);
	}
	public int calculateAge(String dob,DateTimeFormatter dtf)
	{
		String text=dob;
		LocalDate date = LocalDate.parse(text, dtf);
        LocalDate now = LocalDate.now();
        Period diff = Period.between(date, now);
        return diff.getYears();
	}
	public void display(String f,String l,String g,long m,String full_name,int age){
		this.firstName = f;
		this.lastName = l;
		this.gender = g;
		this.mobileNo = m;
		if(ge.M.toString()!=g && ge.F.toString()!=g)
		{
			g=null;
			System.out.println("Please enter a valid gender for "+f);
		}
		else
		{
		System.out.println("Person Details:\n"
				+"____________\n"
				+"\nFirst Name:"+f+"\n"
				+"Last Name:"+l+"\n"
				+"Gender:"+g
				+"\n"+"Mobile Number :"+m+"\n"
				+"Full Name :"+full_name+"\n"
				+"Age :"+age);
	}
		}
}
