package assignment3;

import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1,p2;
		
		p1=new Person();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Please enter Date of Birth in the format dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		String dob=sc.nextLine();
		p1.display("Divya","Bharathi","F",810885855,"DivyaBharathi",20);
		p2=new Person();
		p2.setFirstName("");
		p2.setLastName("");
		p2.setGender("M");
		p2.setMobileNo(703229025);
		p2.display(p2.getFirstName(),p2.getLastName(),p2.getGender(),p2.getMobileNo(),p2.getFullName(),p1.calculateAge(dob,dtf));
		
		
	}
}
