/**
 * 
 */
package FireFox;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.Assert;

/**
 * @author sarulr
 *
 */
public class OpenCartFirefoxTes {
	static FirefoxDriver driver ;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.firefox.bin",
				"C:/Users/sarulr/AppData/Local/Mozilla Firefox/firefox.exe");
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("network.proxy.type", 1);
        profile.setPreference("network.proxy.http", "10.219.96.26");
        profile.setPreference("network.proxy.http_port", 8080);
        profile.setPreference("network.proxy.ssl", "10.219.96.26");
        profile.setPreference("network.proxy.ssl_port", 8080);
        
        driver = new FirefoxDriver(profile);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Closing the browser");
		driver.close();
	}

	/**
	 * @throws java.lang.Exception
	 */
	
	@Test
	public void testTitle() {
		  driver.get("https://demo.opencart.com/");
		String title="Your Store";
		 String verifyTitle=driver.getTitle();
        if(title.equals(verifyTitle))
        		System.out.println("Title is same");
        else
        		System.out.println("Title is not same");

	}
	
	@Test
	public void testCanon() {
		String canonTitle=driver.getTitle();
		String actTitle="Canon";
		System.out.println("Checking title : Canon title "+canonTitle.equals(actTitle));
	}
	
}
