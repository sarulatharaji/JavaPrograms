/**
 * 
 */
package org.openqa.selenium.demos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


/**
 * @author sarulr
 *
 */
public class SeleniumDemo {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("http://newtours.demoaut.com");
			driver.findElement(By.name("userName")).sendKeys("mercury");
			driver.findElement(By.name("password")).sendKeys("mercury");
			driver.findElement(By.name("login")).click();
			Thread.sleep(2000);
//			driver.findElement(By.linkText("Itinerary")).click();
			driver.findElement(By.cssSelector("input[value='oneway']")).click();
			Thread.sleep(1000);
			Select selectSeats=new Select(driver.findElement(By.name("passCount")));
//			selectSeats.selectByIndex(2);
			selectSeats.deselectByValue("1");
			Thread.sleep(2000);
//			selectSeats.selectByVisibleText("3");
			driver.findElement(By.name("findFlights")).submit();
			driver.findElement(By.name("reserveFlights")).submit();
			driver.findElement(By.name("passFirst0")).sendKeys("Sarulatha");
			driver.findElement(By.name("passLast0")).sendKeys("Rajendran");
			driver.findElement(By.name("creditnumber")).sendKeys("895647521865");
			driver.findElement(By.cssSelector("input[name='buyFlights']")).click();
			driver.findElement(By.cssSelector("input[name='buyFlights']")).click();
			driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[1]/td[2]/table/tbody/tr[7]/td/table/tbody/tr/td[2]/a")).click();
//			driver.findElement(By.linkText("Register"));
			driver.findElement(By.linkText("CONTACT")).click();
			driver.findElement(By.linkText("REGISTER")).click();
//				driver.navigate().to("http://newtours.demoaut.com/mercuryregister.php");
//			driver.get("https://google.com");
			
			//System.out.println("Book a Flight: Mercury Tours".equals(driver.getTitle()));
			//System.out.println(driver.getPageSource());
//			driver.close();
			
	}
}
//driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("sara");
//driver.findElement(By.name("password")).sendKeys("sararuja");

//driver.findElement(By.linkText("Profile")).click();
//driver.findElement(By.partialLinkText("Flig")).click();
//System.out.println("Page title is: "+driver.getTitle());