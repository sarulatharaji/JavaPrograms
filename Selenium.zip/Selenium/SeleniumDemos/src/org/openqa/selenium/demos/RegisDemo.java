/**
 * 
 */
package org.openqa.selenium.demos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author sarulr
 *
 */
public class RegisDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("file:///D:/sarulatha/M4/Demos/Web%20Driver%20samples/js-form-validation/example-javascript-form-validation.html");
		driver.findElement(By.xpath("//*[@id='usrID']")).sendKeys("SarulaRaji");
		String title=driver.getTitle();
		System.out.println(title);
		driver.findElement(By.cssSelector("#pwd")).sendKeys("sararuja");
		driver.findElement(By.id("usrname")).sendKeys("Sarulatha");
		driver.findElement(By.name("address")).sendKeys("Navallur");
		
		Select country=new Select(driver.findElement(By.name("country")));
		
		country.selectByIndex(2);
		
		driver.findElement(By.name("zip")).sendKeys("897456");
		driver.findElement(By.className("Format")).sendKeys("sarsa@gmail.com");
		
		driver.findElement(By.cssSelector("input[value='Female']")).click();
	
		driver.findElement(By.name("en")).click();
		driver.findElement(By.name("nonen")).click();
		
		driver.findElement(By.id("desc")).sendKeys("all about registration page");
		driver.findElement(By.xpath("//input[@name='submit']")).click();
		Thread.sleep(1500);
		driver.close();
	}

}
//WebElement checkbox = driver.findElement(By.name("en"));
//if(checkbox.isSelected())
//{
//	checkbox.click();
//}