package org.openqa.selenium.demos;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegistrationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://newtours.demoaut.com");
		driver.findElement(By.linkText("REGISTER"));
		driver.findElement(By.name("firstName")).sendKeys("Sarulatha");
		driver.findElement(By.cssSelector("input[name='lastName']")).sendKeys("Rajendran");
		driver.findElement(By.name("phone")).sendKeys("9856741256");
		driver.findElement(By.id("userName")).sendKeys("sara@gmail.com");
		driver.findElement(By.id("userName")).sendKeys("sara@gmail.com");
		driver.findElement(By.id("userName")).sendKeys("sara@gmail.com");
		driver.findElement(By.id("userName")).sendKeys("sara@gmail.com");
		
	}

}
