package org.openqa.selenium.demos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class RegisTest {
	 static WebDriver driver;
  @Test
  public void f() 
  {
	  String expTitle="JavaScript Form Validation using a sample registration form";
	  String gotTitle=driver.getTitle();
	  System.out.println(gotTitle);
	  Assert.assertEquals(expTitle, gotTitle);
  }
  @BeforeClass
  public void beforeClass() {
//	 driver=new ChromeDriver();
	  System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		 driver=new ChromeDriver();
	 driver.get("file:///D:/sarulatha/M4/Demos/Web%20Driver%20samples/js-form-validation/example-javascript-form-validation.html");
  }

  @AfterClass
  public void afterClass() throws InterruptedException {
	  Thread.sleep(1500);
		driver.close();
  }
}
