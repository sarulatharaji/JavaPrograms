/**
 * 
 */
package org.openqa.selenium.demos;

import static org.junit.Assert.*;


import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author sarulr
 *
 */
public class CookingSchoolPageTest {
	static WebDriver driver;
	/**
	 * @throws java.lang.Exception0
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/sarulatha/M4/Demos/case%20study/Recipe_class_registration.htm");
		System.out.println("Before checking");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("After checking");
		Thread.sleep(1500);
		driver.close();
	}

	//Verifying title
	@Test
	public void test() {

		String expTitle="Online Cooking Class Enquiry Form";
		  String gotTitle=driver.getTitle();
		  System.out.println("Title of the page: "+gotTitle);
		  System.out.println("Verifying title with "+expTitle +" and obtained "+gotTitle);
		  assertEquals(expTitle, gotTitle);
//		fail("Not yet implemented");
	}
	
	//Verifying chosen category
	@Test
	public void testVerifyCategory()
	{
	Select category=new Select(driver.findElement(By.name("D6")));
	category.selectByIndex(1);	
	
	boolean verifyElement=category.getFirstSelectedOption().equals("Non-Veg");
	System.out.println("Verifying Category chosen is Veg "+verifyElement);
	}
	

	//Verifying location chosen is Mumbai
	@Test
	public void testLocation()
	{
		Select city=new Select(driver.findElement(By.name("D5")));
		city.selectByValue("bangalore");
		boolean verifyCity=city.getFirstSelectedOption().equals("mumbai");
		System.out.println("Verifying city chosen is Bangalore "+verifyCity);
	}
	
	//Testing alert
	@Test
	public void testAlert()
	{
		driver.findElement(By.className("auto-style1")).click();
		Alert alert=driver.switchTo().alert();
		String alertMsg=alert.getText();
		System.out.println(alertMsg);
		alert.accept();
	}
	
	//Verifying explicit and implicit wait
	@Test
	public void testWait()
	{
		WebDriverWait w=new WebDriverWait(driver, 30);  
		w.ignoring(NoSuchElementException.class);
		WebElement P=null;
		P=w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select")));
		System.out.println("Explicit wait");
		driver.findElement(By.id("enqdetails")).sendKeys("Regarding Course Timings");
		System.out.println("Implicit wait");
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
	
	//Verifying page content
	@Test
	public void testContent()
	{
		String pageContent = driver.getPageSource();
		if(pageContent .contains("Our location representative will contact you soon."))
			System.out.println("Text is displayed");
		else
			System.out.println("Text isn't visible");
	}

}
