package org.openqa.selenium.demos;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class NavigationDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		String url="https://google.com";
		driver.navigate().to(url);
		System.out.println("url before navigate back"+url);
		String url1="https://www.irctc.co.in";
		driver.navigate().to(url1);
		Thread.sleep(2000);
		System.out.println("back");
		driver.navigate().back();
		Thread.sleep(2000);
		System.out.println(url1+" forward ");
		driver.navigate().forward();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(1500);
		driver.findElement(By.name("q")).sendKeys("say cheese!!!!!!");
		driver.navigate().refresh();
		Thread.sleep(1500);
	}

}
