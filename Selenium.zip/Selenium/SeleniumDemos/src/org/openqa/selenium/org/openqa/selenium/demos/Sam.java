package org.openqa.selenium.org.openqa.selenium.demos;

import static org.junit.Assert.*;


import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class Sam {

	 @Test(expected = ArithmeticException.class)
	 public void calculateResult() {  
	   int result = 4/0;
	 }
}
