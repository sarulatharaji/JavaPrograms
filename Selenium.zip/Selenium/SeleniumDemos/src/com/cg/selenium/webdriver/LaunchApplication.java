/**
 * 
 */
package com.cg.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


/**
 * @author sarulr
 *
 */
public class LaunchApplication {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Loading page using get() method
		driver.get("http://demo.opencart.com/");
		//Verifying page title
		System.out.println("Verifying Home page Title : "+" "+driver.getTitle().equals("Your Store"));
		//Choosing Myaccount from dropdown
		driver.findElement(By.linkText("My Account")).click();
		//Directing to Registration page
		driver.findElement(By.partialLinkText("Reg")).click();
		//Verifying Register account page
		System.out.println("Verifying Register page title : "+" "+driver.getTitle().equals("Register Account"));
		//Filling Registration Page
		driver.findElement(By.id("input-firstname")).sendKeys("Sarulatha");
		driver.findElement(By.id("input-lastname")).sendKeys("Rajendran");
		driver.findElement(By.name("email")).sendKeys("sarakish@gmail.com");
		driver.findElement(By.xpath("//input[@type='tel']")).sendKeys("8974563258");
		driver.findElement(By.cssSelector("input[name='password']")).sendKeys("sararuja");
		driver.findElement(By.cssSelector("input[name='confirm']")).sendKeys("sararuja");
		driver.findElement(By.xpath("//input[@name='newsletter']")).click();
		//Agreeing to policy
		driver.findElement(By.cssSelector("input[name='agree']")).click();
		//Clicking continue button
		driver.findElement(By.xpath("//input[@class='btn btn-primary']")).click();
		Thread.sleep(1500);
		//Verify whether account has been created text is in page or not.
		System.out.println(driver.getPageSource().contains("Your Account Has Been Created!"));
		//Navigating to my account page
		driver.navigate().to("https://demo.opencart.com/index.php?route=account/account");
		//Viewing orders made
		driver.findElement(By.linkText("View your order history")).click();
		Thread.sleep(1500);
		driver.quit();
	}
}