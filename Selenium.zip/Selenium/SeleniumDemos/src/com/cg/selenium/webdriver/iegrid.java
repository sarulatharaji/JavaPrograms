package com.cg.selenium.webdriver;

import java.net.MalformedURLException;
import java.net.URL;

	import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class iegrid {
	public static void main(String[] args) throws InterruptedException, MalformedURLException 

	{
		System.setProperty("webdriver.ie.driver","D:/IEDriverServer.exe");
	
		   
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
		capabilities.setBrowserName("internetExplorer");
		capabilities.setCapability("webdriver.internetExplorer.driver","D:/IEDriverServer.exe");
		

		
		capabilities.setPlatform(Platform.WINDOWS);
		//capabilities.setVersion(version);
	
try {
		driver.get("http://demo.opencart.com/");
		System.out.println(driver.getTitle());
//		driver.quit();
}
catch(Exception ex){
	System.out.println("Hello");
}
//driver.quit();
	}
}





	

		