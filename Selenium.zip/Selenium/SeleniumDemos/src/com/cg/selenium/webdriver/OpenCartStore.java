package com.cg.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenCartStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/sarulatha/M4/Demos/Selenium Grid/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//Loading the opencart website
		driver.get("https://demo.opencart.com");
		
//		//Clicking My account page
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
			
		
		//Selecting register from My account
		driver.findElement(By.partialLinkText("Log")).click();
		
		//Logging details to page
//		driver.findElement(By.id("input-email")).sendKeys("sarulatha@gmail.com");
		driver.findElement(By.xpath("//*[@id='input-email']")).sendKeys("sarulatha@gmail.com");
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("sararuja");
		driver.findElement(By.cssSelector("#content > div > div:nth-child(2) > div > form > input")).click();
	
		
		
		
	}

}
