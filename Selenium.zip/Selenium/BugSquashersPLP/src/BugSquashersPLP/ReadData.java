package BugSquashersPLP;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData {

	public static void main(String[] args) throws IOException 
	{
		
		File src=new File("D:/PLP/Sam.xlsx");

//		
		FileInputStream fis =new FileInputStream(src); 

//		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
//		XSSFSheet sheet=wb.getSheetAt(0);
		
//		int rowCount=sheet.getLastRowNum();
		
//		System.out.println("Total no of rows:"+rowCount);
		
		FileOutputStream fos=new FileOutputStream(src);
		XSSFWorkbook wb1=new XSSFWorkbook();
		XSSFSheet sheet1=wb1.getSheetAt(0);
		wb1.write(fos);
		sheet1.createRow(0).createCell(0).setCellValue("hi");
//		for(int i=0;i<=rowCount;i++)
//		{
//			
//			String username=sheet.getRow(i).getCell(0).getStringCellValue();
//			
//			String password=sheet.getRow(i).getCell(1).getStringCellValue();
//			System.out.println("Username of row "+i+" is: "+username);
//			System.out.println("password of row "+i+" is: "+password);
//		}
		
	}

}
