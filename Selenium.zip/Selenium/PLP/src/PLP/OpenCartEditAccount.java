package PLP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenCartEditAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/PLP/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//Loading the opencart website
		driver.get("https://demo.opencart.com");
		
//		//Clicking My account page
		WebElement myAcc=driver.findElement(By.linkText("My Account"));
		myAcc.click();
		
		//Selecting register from My account
		driver.findElement(By.partialLinkText("Log")).click();
		
		//Logging details to page
		driver.findElement(By.name("email")).sendKeys("sarulatha@gmail.com");
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("sararuja");
		driver.findElement(By.cssSelector("#content > div > div:nth-child(2) > div > form > input")).click();
		
		//Clicking edit your contents
		driver.findElement(By.linkText("Edit your account information")).click();
		
		WebElement fname=driver.findElement(By.id("input-firstname"));
				fname.sendKeys("Sarulatha");
		String firstName=fname.getText();
		String pat="^[a-zA-Z]";
		if(firstName.matches(pat))
			System.out.println("Its has only characters");
		else
			System.out.println("It contains symbols/numerical characters in it");
		
	}

}
