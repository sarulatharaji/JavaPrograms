package PLP;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class OpencartAddValidation {
	public static boolean ValidatefName(String fname){
		//To validate name
		if(Pattern.matches("[a-zA-Z]{1,32}",fname)){
			return true;
		}
		else{
			System.out.println("The user name should be between 1 to 32 characters");
			return false;
		}
	}
	public static boolean Validataddress(String address)
    {
	 Pattern address1 = Pattern.compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	 Matcher mtch = address1.matcher(address);

	 if(mtch.matches()){
            return true;
        }
        else
        {
        	System.out.println("Enter a valid email");
        	System.out.println(address);
        	return false;
        }
}
}