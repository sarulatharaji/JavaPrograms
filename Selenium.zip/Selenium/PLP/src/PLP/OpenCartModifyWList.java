package PLP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenCartModifyWList {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/PLP/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//Loading the opencart website
		driver.get("https://demo.opencart.com");
		
//		//Clicking My account page
		WebElement myAcc=driver.findElement(By.linkText("My Account"));
		myAcc.click();
//			if(myAcc.isSelected())
//				System.out.println("My account page has been loaded");
//			else
//				System.out.println("Unable to load my account page");
		
		//Selecting register from My account
		driver.findElement(By.partialLinkText("Log")).click();
		
		//Logging details to page
//		driver.findElement(By.id("input-email")).sendKeys("sarulatha@gmail.com");
		driver.findElement(By.name("email")).sendKeys("sarulatha@gmail.com");
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("sararuja");
		driver.findElement(By.cssSelector("#content > div > div:nth-child(2) > div > form > input")).click();
		driver.findElement(By.linkText("Modify your wish list")).click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//*[@id='content']/div[1]/table/tbody/tr[1]/td[6]/button")).click();
		Thread.sleep(2500);
		driver.findElement(By.cssSelector("#content > div.buttons.clearfix > div > a")).click();
		driver.findElement(By.xpath("//*[@id='account-account']/ul/li[2]/a")).click();
		driver.findElement(By.partialLinkText("Logo")).click();
		driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
		
	}

}
