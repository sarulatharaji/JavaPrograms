package PLP;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OpenCartEditAccountVal{
	
	public boolean validateName(String patternVal,String fname)
	{
		Pattern pat=Pattern.compile(patternVal);
//		Matcher matcher=Pattern.matches(fname);
		return true;	
	}
}
