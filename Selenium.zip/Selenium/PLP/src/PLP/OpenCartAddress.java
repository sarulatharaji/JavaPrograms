package PLP;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class OpenCartAddress {

	public static void main(String[] args) {
				// TODO Auto-generated method stub

				System.setProperty("webdriver.chrome.driver", "D:/PLP/chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.get("https://demo.opencart.com/index.php?route=account/login");
				String title = "Address Book";
				if(driver.getTitle().equals(title))
				{
					System.out.println("Title: Verified");
				}
				else
				{
					System.out.println("Title: Not verified");
				}
				
				driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
				driver.findElement(By.id("input-email")).sendKeys("sarulatha@gmail.com");
				driver.findElement(By.id("input-password")).sendKeys("sararuja");
				driver.findElement(By.cssSelector("#content > div > div:nth-child(2) > div > form > input")).click();
				System.out.println("Clicked: Login button");
				driver.findElement(By.linkText("Modify your address book entries")).click();
				System.out.println("Clicked:  Modify your address book entries");
				driver.findElement(By.linkText("New Address")).click();
				System.out.println("Clicked: New address");
				
				
				//Fill up the fields
				Scanner sc = new Scanner(System.in);
				driver.findElement(By.id("input-firstname")).sendKeys("swathi");
				WebElement first = driver.findElement(By.name("firstname"));
				String fname = first.getAttribute("value");
				if(OpencartAddValidation.ValidatefName(fname))
				{
					System.out.println("First name is verified");
				}
				else
				{
					System.out.println("First name is not verified");
				}

				driver.findElement(By.id("input-lastname")).sendKeys("kushi");
				
				WebElement last = driver.findElement(By.name("lastname"));
				String lname = last.getAttribute("value");
				driver.findElement(By.name("company")).sendKeys("capgemini");
				driver.findElement(By.name("address_1")).sendKeys("2-24/a, aganampudi");
				String address1 = first.getAttribute ("value");
				if(OpencartAddValidation.Validataddress(address1))
				{
					System.out.println("Address1 is verified");
				}
				else
				{
					System.out.println("Address1 is not verified");
				}
				driver.findElement(By.name("address_2")).sendKeys("Gajuwaka");
				driver.findElement(By.id("input-city")).sendKeys("visakhapatnam");
				driver.findElement(By.id("input-postcode")).sendKeys("530046");
//				Select country=new Select(driver.findElement(By.xpath("//*[@id='input-country']")));
////				country.deselectByVisibleText("United Kingdom");
//				country.selectByValue("99");
				Select fromCountry= new Select(driver.findElement(By.id("input-country")));
				fromCountry.selectByIndex(106);
			    //Thread.sleep(1000);
			    WebElement Country = fromCountry.getFirstSelectedOption();
				String country = Country.getText();
				if(country.equals("India"))
					System.out.println("India is selected");
				else
					System.out.println("Other country is selected");
	}

}
